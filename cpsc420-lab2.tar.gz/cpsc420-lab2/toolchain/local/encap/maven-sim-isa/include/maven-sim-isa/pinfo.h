//========================================================================
// pinfo.h : Program argument and module information repository
//========================================================================
// See 'pinfo-uguide.txt' for more information about using the program
// info subproject.

#ifndef PINFO_H
#define PINFO_H

#include "pinfo-ProgramInfo.h"

#endif /* PINFO_H */

